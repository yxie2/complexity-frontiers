# Dimensions of permanental varieties in arbitrary size

Ying Xie, Kennesaw State University, yxie2@kennesaw.edu

Zenodo preprint: https://zenodo.org/records/22901136  
DOI: https://doi.org/10.5281/zenodo.22901136

## Contents

`main.tex` contains the manuscript and bibliography. `build.py` runs a two-pass
PDF build. `verify.py` contains the exact finite checks, and
`verification_results.json` records their expected output. `CITATION.cff`
contains citation metadata. `MANIFEST.json` records file sizes and SHA-256 hashes.
The submission package also includes the published manuscript as `paper.pdf`.

## Build the manuscript

Install a TeX distribution with pdflatex, Latin Modern, geometry, amsmath,
amssymb, amsthm, mathtools, microtype, and hyperref. From this directory, run:

```sh
python build.py
```

The resulting file is `build/main.pdf`.

## Reproduce the checks

Python 3.10 or newer is sufficient; no additional packages are required.

```sh
python verify.py --compare verification_results.json
```

The expected results comprise 817 exact polynomial equalities for sizes 2
through 5 and 87,376 support cases for sizes 2 through 8. These computations
supplement the written proofs and do not establish the arbitrary-size theorems
by finite inference.

## Citation and licenses

Ying Xie. *Dimensions of permanental varieties in arbitrary size*. Zenodo,
2026. https://doi.org/10.5281/zenodo.22901136.

The manuscript and LaTeX source are licensed under CC BY 4.0; see `LICENSE.md`.
Code, result records, and documentation are licensed under the MIT License;
see `LICENSE_CODE`.
