# Paper and reproducibility files

This archive accompanies Ying Xie's *Sharp FRS and singularity thresholds for
off-diagonal Gram maps*. Share this complete archive with readers who
need to check the computations. The review PDF also embeds all ancillary
files and `gram_verification_code.zip` as document attachments. Open the
PDF reader's Attachments panel, save that ZIP, and extract it to obtain
the same `anc/` directory. Some browser previews do not expose attachments;
use a PDF reader with an Attachments panel or the external ZIP in that case.

- `paper.pdf`: the manuscript with 11 document attachments (ten ancillary
  files and a ZIP containing the same ancillary directory).
- `main.tex`: its source, with an embedded bibliography.
- `anc/`: all four Python verification programs, their four recorded JSON
  outputs, reproduction instructions, and ancillary checksums.
- `SHA256SUMS.txt`: hashes for every other file in this archive.

The manuscript is a draft that has not undergone peer review. Its
acknowledgment uses the author-approved standard wording. The finite checks supplement the proofs;
they do not establish the all-size statements or the geometric arguments.

## Reproduce the computations

Extract the entire archive. Python 3.11 or later is required; no third-party
Python packages or internet access are needed. From the extracted root, run:

```text
python -X utf8 anc/check_gram_fourier_arithmetic.py
python -X utf8 anc/check_direct_gram_counts.py
python -X utf8 anc/check_odd_gram_first_jets.py
python -X utf8 anc/check_valuation_strata.py
```

Keep all four scripts together. The first-jet program imports the ring
implementation from the direct-count program. The longest run takes about
two minutes on the development machine; timings vary by computer.
Each successful program writes a JSON result beside its script with
top-level `status: PASS` and a hash of the producing script.

The four programs were run from a fresh extraction of this review archive.
Their outputs matched the supplied results after excluding the top-level
`seconds` field. Reruns overwrite the JSON files, so preserve a copy of the
supplied results and check the distributed hashes before running them.
See `anc/README.md` for the scope and limitations of each check.

To verify the extracted files before rerunning, use:

```text
python -c "from pathlib import Path; import hashlib; rows=[s.split('  ',1) for s in Path('SHA256SUMS.txt').read_text().splitlines()]; assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for h,p in rows); print('PASS')"
```

## Rebuild the PDF

PDFLaTeX is required only for rebuilding the manuscript. From the extracted
root, run:

```text
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape main.tex
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape main.tex
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape main.tex
```

The build produces `main.pdf`; repeat if LaTeX still requests another pass
for cross-references. No BibTeX pass or external figure is needed.
This compiles the typeset pages without PDF document attachments. The
delivery build adds the exact ancillary files and a deterministic code ZIP
using pypdf. Both the clean typeset build and the same attachment step
were reproduced and compared with the delivered PDF. Other TeX
distributions may produce different PDF bytes without changing the content.

This review archive is for sharing the paper and code together. For arXiv,
use the separate source submission ZIP, which contains `main.tex` and
`anc/` and omits the prebuilt PDF and this distribution README. No arXiv
submission or public repository upload has been made by this revision.
