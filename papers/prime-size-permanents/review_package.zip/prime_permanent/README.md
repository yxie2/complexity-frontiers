# Frobenius splitting and singular loci of prime-size permanents

Ying Xie, Kennesaw State University, yxie2@kennesaw.edu.

The manuscript is provided for expert mathematical review. Its proof and
novelty have not been independently certified. The acknowledgment is retained
in the manuscript.

Files:
- `main.tex`: self-contained LaTeX manuscript, including the bibliography.
- `main.pdf`: compiled manuscript.
- `verify.py`: exact finite verification; run with Python 3, without `-O`.
- `verification_results.json`: recorded output of that verification.

Compile with `pdflatex -interaction=nonstopmode -halt-on-error main.tex`
twice. Required packages are standard: fontenc, lmodern, amsmath, amssymb,
amsthm, microtype, geometry, and hyperref. The three-by-four paper also loads
booktabs. Run `python verify.py` to reproduce the supplementary checks.
Only the Python standard library is needed. Finite computations check
particular identities and examples; they are not a proof assistant or a
substitute for review of the general arguments.

The verification also expands every cofactor obtained by deleting a bottom
row and a bottom column for sizes 3 through 7. It compares the complete
integer monomial expansions with equation (6.5) and checks their degrees
in the free block. Proposition 6.2 includes the general counting argument.
