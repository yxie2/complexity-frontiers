Exact verification data and code for
Sharp Newton-edge bounds and cancellation families with one nonzero quadratic norm
Ying Xie, Kennesaw State University

Extract verification.zip into an empty directory. With Python 3.11 or later, run:

    python -B -X utf8 verify.py

The archive includes instructions, a file manifest, all five checking programs,
their supporting modules, the complete finite certificates, and example inputs.
Only the Python standard library is required.
