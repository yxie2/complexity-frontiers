# F-purity of the maximal permanental ideal of a generic three-by-four matrix

Ying Xie, Kennesaw State University, yxie2@kennesaw.edu.

The manuscript is provided for expert mathematical review. Its proof and
novelty have not been independently certified. The acknowledgment is retained
in the manuscript.

Files:
- `main.tex`: self-contained LaTeX manuscript, including the bibliography.
- `main.pdf`: compiled manuscript.
- `verify.py`: exact finite verification; run with Python 3, without `-O`.
- `verification_results.json`: recorded output of that verification.

Compile with `pdflatex -interaction=nonstopmode -halt-on-error main.tex`
twice. Required packages are standard: fontenc, lmodern, amsmath, amssymb,
amsthm, microtype, geometry, and hyperref. The three-by-four paper also loads
booktabs. Run `python verify.py` to reproduce the supplementary checks.
Only the Python standard library is needed. Finite computations check
particular identities and examples; they are not a proof assistant or a
substitute for review of the general arguments.

`verification_support.py` contains exact polynomial arithmetic and the projective-column counting routine used by `verify.py`.
